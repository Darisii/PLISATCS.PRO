import discord
from discord.ext import commands, tasks
import json
import socket

with open("config.json") as f:
    config = json.load(f)

TOKEN = config["token"]
SERVER_IP = config["server_ip"]
SERVER_PORT = config["server_port"]

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

def check_server(ip, port):
    try:
        sock = socket.create_connection((ip, port), timeout=2)
        sock.close()
        return True
    except:
        return False

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")
    status_task.start()

@tasks.loop(seconds=60)
async def status_task():
    online = check_server(SERVER_IP, SERVER_PORT)

    if online:
        await bot.change_presence(activity=discord.Game(name="🟢 Server Online"))
    else:
        await bot.change_presence(activity=discord.Game(name="🔴 Server Offline"))

@bot.command()
async def status(ctx):
    online = check_server(SERVER_IP, SERVER_PORT)

    if online:
        await ctx.send("🟢 Server is ONLINE!")
    else:
        await ctx.send("🔴 Server is OFFLINE!")

bot.run(TOKEN)
