# PLISATCS.PRO Bot

Simple Discord bot to check CS2 server status.

## Setup
pip install -r requirements.txt
python bot.py
